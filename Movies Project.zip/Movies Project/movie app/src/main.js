// import './assets/main.css'
// pour l'utilisatio  de bootstrapp
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap/dist/js/bootstrap.js'

import 'bootstrap/dist/css/bootstrap.min.css'
// import 'jquery/src/jquery.js'
import 'bootstrap/dist/js/bootstrap.min.js' 

import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app')
