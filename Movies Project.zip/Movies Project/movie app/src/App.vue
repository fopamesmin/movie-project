<script setup>

import GeneralData_Movies from './components/GeneralData_Movies.vue'
</script>

<template>

    <GeneralData_Movies />
</template>

<style >

</style>
